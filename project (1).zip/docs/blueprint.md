# **App Name**: Dari

## Core Features:

- Phone Number Authentication: Secure user registration and login using phone number for personalized access to features.
- Property Search and Filtering: Allow users to browse and filter real estate listings based on criteria like rent/buy status, location, and property type.
- Property Listing Creation: Enable users to submit new property listings with essential details such as address, price, and property type.
- Amenity & Image Uploads: Facilitate the inclusion of property amenities (e.g., gas, water, internet) and upload multiple high-resolution images for each listing.
- AI-Powered Property Description Tool: Automatically generate engaging and detailed property descriptions based on the entered property features and amenities, assisting sellers in creating compelling listings.
- Data Storage and Retrieval: Securely store and retrieve all user accounts and property listings data.

## Style Guidelines:

- Color Anchor: 'Dari' (home), suggesting warmth, comfort, and architectural natural materials. Light color scheme chosen to emphasize openness and welcome. Primary color: a rich, earthy brown-orange (#A35629), reflecting natural warmth and a sense of belonging. Background color: a soft, light beige (#F7F0ED), providing a clean and inviting canvas that harmonizes with the primary tone. Accent color: a vibrant golden orange (#F5B631), used to highlight key actions and information, adding a touch of energy and visibility while maintaining warmth.
- Headline font: 'Space Grotesk' (sans-serif), chosen for its modern, clean lines and readability, giving titles a distinctive yet professional look. Body font: 'Inter' (sans-serif), selected for its excellent legibility and versatility, ideal for property details, user input, and descriptive texts, ensuring clarity and a smooth reading experience across the application.
- Utilize modern, clean line icons for navigation and features, ensuring quick comprehension without clutter. Icons for amenities (gas, water, internet) should be universally recognizable.
- Implement a responsive design that ensures seamless user experience across all devices. Employ a clean, modular card-based layout for property listings, allowing for easy scanning and visually organized content. Prioritize clear hierarchy of information.
- Incorporate subtle, tasteful micro-animations for user feedback, such as loading states, button presses, and successful form submissions, enhancing interactivity and user satisfaction without distraction.