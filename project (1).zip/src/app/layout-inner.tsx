
'use client';

import { useLanguage } from '@/context/language-context';

export function RootLayoutInner({ children }: { children: React.ReactNode }) {
  const { t } = useLanguage();
  
  return (
    <html lang={t.dir === 'rtl' ? 'ar' : 'fr'} dir={t.dir}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased">
        {children}
      </body>
    </html>
  );
}
