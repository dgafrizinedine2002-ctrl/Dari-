
"use client"

import { useState, useRef, useEffect } from "react";
import { Navbar } from "@/components/navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { generatePropertyDescription } from "@/ai/flows/ai-powered-property-description-generation-flow";
import { Loader2, Sparkles, Upload, Building2, Home as HomeIcon, X, MapPin, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { useFirestore, useUser } from "@/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { useLanguage } from "@/context/language-context";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function AddPropertyPage() {
  const { t } = useLanguage();
  const { user, loading: authLoading } = useUser();
  const { toast } = useToast();
  const router = useRouter();
  const db = useFirestore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [fetchingLocation, setFetchingLocation] = useState(false);
  const [step, setStep] = useState(1);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    title: "",
    propertyType: "apartment", 
    transactionType: "rent",
    location: "",
    price: "",
    ownerPhone: "",
    bedrooms: "" as string | number,
    bathrooms: "" as string | number,
    areaSqM: "" as string | number,
    floorNumber: "" as string | number,
    latitude: null as number | null,
    longitude: null as number | null,
    hasElevator: false,
    hasSecurity: false,
    isFurnished: false,
    amenities: [] as string[],
    additionalFeatures: "",
    description: ""
  });

  // حماية الصفحة: توجيه المستخدم لصفحة الدخول إذا لم يكن مسجلاً مع تحديد رابط العودة
  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "تسجيل الدخول مطلوب",
        description: "يجب تسجيل الدخول لنشر إعلان جديد.",
        variant: "destructive"
      });
      router.push("/login?redirect=/add");
    }
  }, [user, authLoading, router, toast]);

  if (authLoading || !user) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  const amenitiesOptions = [
    { id: "gas", label: t.add.gas },
    { id: "water", label: t.add.water },
    { id: "internet", label: t.add.internet },
    { id: "parking", label: t.add.parking },
    { id: "garden", label: t.add.garden },
    { id: "baroudage", label: t.add.baroudage },
    { id: "iron_door", label: t.add.ironDoor },
    { id: "water_tank", label: t.add.waterTank }
  ];

  const handleAmenityChange = (id: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      amenities: checked 
        ? [...prev.amenities, id] 
        : prev.amenities.filter(a => a !== id)
    }));
  };

  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Geolocation is not supported by your browser."
      });
      return;
    }

    setFetchingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setFormData(prev => ({
          ...prev,
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        }));
        setFetchingLocation(false);
        toast({
          title: t.add.locationSuccess,
          description: `${position.coords.latitude}, ${position.coords.longitude}`
        });
      },
      (error) => {
        setFetchingLocation(false);
        toast({
          variant: "destructive",
          title: "Location Error",
          description: error.message
        });
      }
    );
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const remainingSlots = 5 - imagePreviews.length;
      const filesToUpload = Array.from(files).slice(0, remainingSlots);

      if (Array.from(files).length > remainingSlots) {
        toast({
          variant: "destructive",
          title: "حد الصور",
          description: "يمكنك إضافة 5 صور كحد أقصى لضمان جودة النشر."
        });
      }

      filesToUpload.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setImagePreviews(prev => [...prev, reader.result as string]);
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeImage = (index: number) => {
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
  };

  const handleNumericChange = (field: string, value: string) => {
    if (value === "") {
      setFormData(prev => ({ ...prev, [field]: "" }));
      return;
    }
    const num = parseInt(value);
    if (!isNaN(num)) {
      setFormData(prev => ({ ...prev, [field]: num }));
    }
  };

  const handleGenerateDescription = async () => {
    if (!formData.location || !formData.areaSqM) {
      toast({
        variant: "destructive",
        title: "بيانات ناقصة",
        description: "يرجى ملء الموقع والمساحة أولاً لتوليد الوصف."
      });
      return;
    }

    setGenerating(true);
    try {
      const amenityLabels = formData.amenities.map(id => 
        amenitiesOptions.find(opt => opt.id === id)?.label || id
      );

      const result = await generatePropertyDescription({
        propertyType: formData.propertyType === 'apartment' ? 'شقة' : 'منزل',
        transactionType: formData.transactionType === 'rent' ? 'كراء' : 'بيع',
        location: formData.location,
        bedrooms: Number(formData.bedrooms) || 0,
        bathrooms: Number(formData.bathrooms) || 0,
        areaSqM: Number(formData.areaSqM) || 0,
        amenities: amenityLabels,
        additionalFeatures: formData.additionalFeatures
      });

      setFormData(prev => ({ ...prev, description: result.description }));
      toast({
        title: "نجاح",
        description: "تم توليد الوصف بنجاح."
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "خطأ",
        description: "فشل توليد الوصف الذكي."
      });
    } finally {
      setGenerating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (!db || !user) {
      toast({ variant: "destructive", title: "خطأ", description: "يجب تسجيل الدخول أولاً." });
      return;
    }

    if (!formData.location || !formData.price || !formData.ownerPhone || !formData.description) {
      toast({ variant: "destructive", title: "بيانات مطلوبة", description: "يرجى ملء كافة الحقول الأساسية والوصف." });
      return;
    }
    
    setLoading(true);

    const propertyData = {
      title: formData.title || `${formData.propertyType === 'apartment' ? 'Apartment' : 'House'} in ${formData.location}`,
      propertyType: formData.propertyType,
      transactionType: formData.transactionType,
      location: formData.location,
      price: Number(formData.price),
      ownerPhone: formData.ownerPhone,
      ownerUid: user.uid,
      views: 0,
      latitude: formData.latitude,
      longitude: formData.longitude,
      bedrooms: Number(formData.bedrooms) || 0,
      bathrooms: Number(formData.bathrooms) || 0,
      areaSqM: Number(formData.areaSqM) || 0,
      roomType: formData.bedrooms ? `F${formData.bedrooms}` : "Studio",
      imageUrl: imagePreviews[0] || "https://picsum.photos/seed/dari/800/600",
      images: imagePreviews, 
      amenities: formData.amenities,
      description: formData.description,
      isFurnished: formData.isFurnished,
      isFeatured: false,
      createdAt: serverTimestamp()
    };

    addDoc(collection(db, "properties"), propertyData)
      .then(() => {
         toast({
          title: t.add.success,
          description: t.add.successSub,
        });
        setTimeout(() => {
          router.push("/");
        }, 800);
      })
      .catch(async (error) => {
        console.error("Publishing error:", error);
        const permissionError = new FirestorePermissionError({
          path: "properties",
          operation: "create",
          requestResourceData: propertyData,
        });
        errorEmitter.emit('permission-error', permissionError);
        setLoading(false);
        toast({
          variant: "destructive",
          title: "فشل النشر",
          description: "حدث خطأ أثناء حفظ الإعلان. قد يكون حجم الصور كبيراً جداً."
        });
      });
  };

  const nextStep = () => setStep(prev => Math.min(prev + 1, 3));
  const prevStep = () => setStep(prev => Math.max(prev - 1, 1));

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      
      <div className="container mx-auto px-6 pt-12 max-w-3xl">
        <div className="mb-10 text-center">
          <h1 className="text-4xl font-headline font-black text-primary mb-2 tracking-tight">{t.add.title}</h1>
          <p className="text-muted-foreground text-lg font-medium">{t.add.subtitle}</p>
        </div>

        <div className="flex justify-between items-center mb-16 relative px-4 max-w-sm mx-auto">
          <div className="absolute top-1/2 left-0 w-full h-1 bg-secondary -translate-y-1/2 z-0 rounded-full" />
          <div 
            className="absolute top-1/2 left-0 h-1 bg-primary -translate-y-1/2 z-0 transition-all duration-700 rounded-full shadow-[0_0_15px_rgba(var(--primary),0.3)]" 
            style={{ 
              width: `${((step - 1) / 2) * 100}%`,
              [t.dir === 'rtl' ? 'right' : 'left']: 0,
              [t.dir === 'rtl' ? 'left' : 'right']: 'auto'
            }}
          />
          {[1, 2, 3].map((s) => (
            <div 
              key={s} 
              className={`relative z-10 w-12 h-12 rounded-2xl flex items-center justify-center font-black transition-all duration-500 shadow-lg ${step >= s ? 'bg-primary text-primary-foreground scale-110 shadow-primary/30' : 'bg-card text-muted-foreground border-2 border-secondary'}`}
            >
              {s}
            </div>
          ))}
        </div>

        {step === 1 && (
          <Card className="animate-in fade-in slide-in-from-bottom-8 duration-700 rounded-[2.5rem] border-none shadow-[0_20px_50px_rgba(0,0,0,0.08)] overflow-hidden">
            <CardHeader className="text-center pt-8">
              <CardTitle className="text-xl font-black text-primary uppercase tracking-wider">{t.add.step1}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-8 pt-6 p-8 sm:p-12">
              <div className="space-y-4">
                <Label className="text-sm font-black text-foreground/70 uppercase tracking-widest">{t.add.transactionType}</Label>
                <RadioGroup 
                  defaultValue={formData.transactionType} 
                  onValueChange={(v) => setFormData({...formData, transactionType: v})}
                  className="grid grid-cols-2 gap-4"
                >
                  <Label 
                    htmlFor="rent" 
                    className={`flex items-center justify-center gap-3 p-5 rounded-2xl border-2 cursor-pointer transition-all ${formData.transactionType === 'rent' ? 'border-primary bg-primary/5 shadow-inner' : 'border-secondary hover:border-primary/30'}`}
                  >
                    <RadioGroupItem value="rent" id="rent" className="sr-only" />
                    <span className="font-black text-lg">{t.property.rent}</span>
                  </Label>
                  <Label 
                    htmlFor="sale" 
                    className={`flex items-center justify-center gap-3 p-5 rounded-2xl border-2 cursor-pointer transition-all ${formData.transactionType === 'sale' ? 'border-primary bg-primary/5 shadow-inner' : 'border-secondary hover:border-primary/30'}`}
                  >
                    <RadioGroupItem value="sale" id="sale" className="sr-only" />
                    <span className="font-black text-lg">{t.property.sale}</span>
                  </Label>
                </RadioGroup>
              </div>

              <div className="space-y-4">
                <Label className="text-sm font-black text-foreground/70 uppercase tracking-widest">{t.add.propertyType}</Label>
                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => setFormData({...formData, propertyType: 'apartment'})}
                    className={`flex flex-col items-center gap-4 p-8 rounded-[2rem] border-2 transition-all ${formData.propertyType === 'apartment' ? 'border-primary bg-primary/5 shadow-lg' : 'border-secondary hover:border-primary/30'}`}
                  >
                    <Building2 className={`w-10 h-10 ${formData.propertyType === 'apartment' ? 'text-primary' : 'text-muted-foreground'}`} />
                    <span className="font-black text-base">{t.add.apartment}</span>
                  </button>
                  <button 
                    onClick={() => setFormData({...formData, propertyType: 'house'})}
                    className={`flex flex-col items-center gap-4 p-8 rounded-[2rem] border-2 transition-all ${formData.propertyType === 'house' ? 'border-primary bg-primary/5 shadow-lg' : 'border-secondary hover:border-primary/30'}`}
                  >
                    <HomeIcon className={`w-10 h-10 ${formData.propertyType === 'house' ? 'text-primary' : 'text-muted-foreground'}`} />
                    <span className="font-black text-base">{t.add.house}</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label htmlFor="location" className="font-black text-lg px-2">{t.add.location}</Label>
                  <div className="flex gap-2">
                    <Input 
                      id="location" 
                      placeholder={t.add.location} 
                      className="h-14 rounded-2xl flex-1 bg-secondary/30 border-none font-bold text-base"
                      value={formData.location}
                      onChange={(e) => setFormData({...formData, location: e.target.value})}
                    />
                    <Button 
                      variant="outline" 
                      onClick={handleGetLocation} 
                      disabled={fetchingLocation}
                      className="h-14 w-14 rounded-2xl p-0 border-primary text-primary hover:bg-primary/5"
                    >
                      {fetchingLocation ? <Loader2 className="animate-spin" /> : <MapPin className="w-6 h-6" />}
                    </Button>
                  </div>
                </div>
                <div className="space-y-3">
                  <Label htmlFor="price" className="font-black text-lg px-2">{t.add.price}</Label>
                  <Input 
                    id="price" 
                    type="number" 
                    placeholder={t.add.price} 
                    className="h-14 rounded-2xl bg-secondary/30 border-none font-black text-lg"
                    value={formData.price}
                    onChange={(e) => setFormData({...formData, price: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="ownerPhone" className="font-black text-lg px-2">{t.add.ownerPhone} *</Label>
                <Input 
                  id="ownerPhone" 
                  type="tel" 
                  placeholder={t.add.ownerPhonePlaceholder} 
                  className="h-14 rounded-2xl border-2 border-primary/20 focus:border-primary font-black text-lg text-primary bg-primary/5"
                  value={formData.ownerPhone}
                  onChange={(e) => setFormData({...formData, ownerPhone: e.target.value})}
                  required
                />
              </div>

              <div className="flex justify-end pt-6">
                <Button 
                  onClick={nextStep} 
                  disabled={!formData.ownerPhone || !formData.location || !formData.price}
                  className="h-14 px-12 rounded-2xl font-black text-lg shadow-xl shadow-primary/20 bg-primary text-primary-foreground hover:scale-105 transition-all"
                >
                  {t.add.next}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 2 && (
          <Card className="animate-in fade-in slide-in-from-bottom-8 duration-700 rounded-[2.5rem] border-none shadow-[0_20px_50px_rgba(0,0,0,0.08)]">
            <CardHeader className="text-center pt-8">
              <CardTitle className="text-xl font-black text-primary uppercase tracking-wider">{t.add.step2}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-8 pt-6 p-8 sm:p-12">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2 text-center">
                  <Label className="font-black text-xs uppercase opacity-60">{t.add.rooms}</Label>
                  <Input 
                    type="number" 
                    className="h-14 text-center font-black rounded-2xl bg-secondary/30 border-none text-xl"
                    value={formData.bedrooms}
                    onChange={(e) => handleNumericChange('bedrooms', e.target.value)}
                    placeholder="0"
                  />
                </div>
                <div className="space-y-2 text-center">
                  <Label className="font-black text-xs uppercase opacity-60">{t.add.bathrooms}</Label>
                  <Input 
                    type="number" 
                    className="h-14 text-center font-black rounded-2xl bg-secondary/30 border-none text-xl"
                    value={formData.bathrooms}
                    onChange={(e) => handleNumericChange('bathrooms', e.target.value)}
                    placeholder="0"
                  />
                </div>
                <div className="space-y-2 text-center">
                  <Label className="font-black text-xs uppercase opacity-60">{t.add.areaSqM}</Label>
                  <Input 
                    type="number" 
                    className="h-14 text-center font-black rounded-2xl bg-secondary/30 border-none text-xl"
                    value={formData.areaSqM}
                    onChange={(e) => handleNumericChange('areaSqM', e.target.value)}
                    placeholder="0"
                  />
                </div>
              </div>

              {formData.propertyType === 'apartment' && (
                <div className="grid grid-cols-1 gap-6 p-8 bg-secondary/20 rounded-[2rem] border-2 border-dashed border-primary/20">
                   <div className="space-y-3">
                    <Label className="font-black text-base">{t.add.floor}</Label>
                    <Input 
                      type="number" 
                      className="h-14 rounded-2xl font-black text-lg bg-card border-none shadow-sm"
                      value={formData.floorNumber}
                      onChange={(e) => handleNumericChange('floorNumber', e.target.value)}
                      placeholder="0"
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex items-center justify-between p-4 bg-card rounded-2xl shadow-sm">
                      <Label className="font-black text-base">{t.add.elevator}</Label>
                      <Switch 
                        checked={formData.hasElevator}
                        onCheckedChange={(v) => setFormData({...formData, hasElevator: v})}
                        className="data-[state=checked]:bg-primary"
                      />
                    </div>
                    <div className="flex items-center justify-between p-4 bg-card rounded-2xl shadow-sm">
                      <Label className="font-black text-base">{t.add.security}</Label>
                      <Switch 
                        checked={formData.hasSecurity}
                        onCheckedChange={(v) => setFormData({...formData, hasSecurity: v})}
                        className="data-[state=checked]:bg-primary"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between p-8 bg-primary/5 rounded-[2rem] border-2 border-primary/10 transition-all hover:bg-primary/10">
                <div className="space-y-1">
                  <Label className="font-black text-xl text-primary">{t.add.furnished}</Label>
                  <p className="text-sm text-muted-foreground font-medium">{t.add.furnishedSub}</p>
                </div>
                <Switch 
                  checked={formData.isFurnished}
                  onCheckedChange={(checked) => setFormData({...formData, isFurnished: checked})}
                  className="scale-125 data-[state=checked]:bg-primary"
                />
              </div>

              <div className="space-y-6">
                <Label className="text-lg font-black text-foreground/80 block uppercase tracking-widest">{t.add.amenities}</Label>
                <div className="grid grid-cols-2 gap-3">
                  {amenitiesOptions.map(opt => (
                    <div key={opt.id} className="flex items-center gap-3 p-4 bg-secondary/20 rounded-2xl transition-all hover:bg-secondary/40 border border-transparent hover:border-primary/20">
                      <Checkbox 
                        id={opt.id} 
                        checked={formData.amenities.includes(opt.id)}
                        onCheckedChange={(checked) => handleAmenityChange(opt.id, !!checked)}
                        className="w-5 h-5 rounded-md border-primary"
                      />
                      <Label htmlFor={opt.id} className="font-black text-sm sm:text-base cursor-pointer">{opt.label}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <Label className="text-lg font-black text-foreground/80 block uppercase tracking-widest">{t.add.images}</Label>
                  <span className="text-xs font-bold text-muted-foreground">{imagePreviews.length} / 5</span>
                </div>
                
                <Alert className="bg-primary/5 border-primary/20">
                  <AlertCircle className="h-4 w-4 text-primary" />
                  <AlertTitle className="text-primary font-bold">تنبيه حجم الصور</AlertTitle>
                  <AlertDescription className="text-xs">
                    يرجى رفع صور ذات حجم معقول لضمان نجاح نشر الإعلان. الحد الأقصى 5 صور.
                  </AlertDescription>
                </Alert>

                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed border-primary/20 rounded-[2rem] p-12 text-center bg-primary/5 cursor-pointer group hover:bg-primary/10 hover:border-primary/40 transition-all ${imagePreviews.length >= 5 ? 'opacity-50 pointer-events-none' : ''}`}
                >
                  <Upload className="w-12 h-12 mx-auto mb-4 text-primary/40 group-hover:text-primary transition-all" />
                  <p className="font-black text-primary text-lg">{t.add.upload}</p>
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    multiple 
                    onChange={handleImageUpload} 
                    disabled={imagePreviews.length >= 5}
                  />
                </div>

                {imagePreviews.length > 0 && (
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-3 mt-6">
                    {imagePreviews.map((src, idx) => (
                      <div key={idx} className="relative aspect-square rounded-2xl overflow-hidden shadow-lg border-2 border-white">
                        <Image src={src} alt="Preview" fill className="object-cover" />
                        <button 
                          onClick={(e) => { e.stopPropagation(); removeImage(idx); }} 
                          className="absolute top-1 right-1 bg-destructive text-white p-1 rounded-lg shadow-md hover:bg-destructive/90"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-between pt-8">
                <Button variant="ghost" onClick={prevStep} className="h-14 px-8 rounded-2xl font-black text-base">{t.add.prev}</Button>
                <Button onClick={nextStep} className="h-14 px-12 rounded-2xl font-black text-lg bg-primary text-primary-foreground hover:scale-105 transition-all shadow-xl shadow-primary/20">{t.add.next}</Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 3 && (
          <Card className="animate-in fade-in slide-in-from-bottom-8 duration-700 rounded-[2.5rem] border-none shadow-[0_20px_50px_rgba(0,0,0,0.08)] overflow-hidden">
            <div className="bg-gradient-to-br from-primary to-primary/80 p-12 text-primary-foreground text-center">
              <Sparkles className="w-12 h-12 mx-auto mb-6 text-accent animate-pulse" />
              <CardTitle className="text-3xl font-black tracking-tight">{t.add.aiTitle}</CardTitle>
            </div>
            <CardContent className="space-y-8 pt-10 p-8 sm:p-12">
              <Button 
                onClick={handleGenerateDescription} 
                disabled={generating}
                className="w-full h-20 gap-4 rounded-2xl text-xl font-black shadow-xl bg-primary text-primary-foreground hover:scale-[1.02] transition-all"
              >
                {generating ? <Loader2 className="animate-spin w-8 h-8" /> : <Sparkles className="w-8 h-8 text-accent" />}
                {generating ? t.add.aiLoading : t.add.aiBtn}
              </Button>

              <div className="space-y-4">
                <Label className="font-black text-xl text-primary/80 px-2">{t.add.descriptionLabel}</Label>
                <Textarea 
                  rows={10}
                  placeholder={t.add.descriptionPlaceholder}
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="rounded-[2rem] p-8 min-h-[300px] text-lg font-medium leading-relaxed bg-secondary/10 border-none shadow-inner resize-none focus-visible:ring-primary/30"
                />
              </div>

              <div className="flex justify-between pt-6">
                <Button variant="ghost" onClick={prevStep} className="h-14 px-8 rounded-2xl font-black text-base">{t.add.prev}</Button>
                <Button 
                  onClick={handleSubmit} 
                  disabled={loading || !formData.description} 
                  className="h-16 px-16 rounded-2xl font-black text-2xl bg-primary text-primary-foreground hover:scale-105 transition-all shadow-xl shadow-primary/30"
                >
                  {loading ? <Loader2 className="animate-spin w-8 h-8" /> : t.add.submit}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
