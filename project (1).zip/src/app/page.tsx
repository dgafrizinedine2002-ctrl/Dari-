
"use client"

import { useState, useMemo } from "react";
import { Navbar } from "@/components/navbar";
import { PropertyCard } from "@/components/property-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Search, SlidersHorizontal, Check, Loader2, Home as HomeIcon, Plus, Sparkles, Star } from "lucide-react";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Image from "next/image";
import Link from "next/link";
import { useCollection } from "@/firebase";
import { collection, query, orderBy } from "firebase/firestore";
import { useFirestore } from "@/firebase";
import { useLanguage } from "@/context/language-context";
import { formatAlgerianCurrency } from "@/lib/currency-formatter";

export default function HomePage() {
  const db = useFirestore();
  const { t, language } = useLanguage();
  const [activeType, setActiveType] = useState<"all" | "rent" | "sale">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [maxPrice, setMaxPrice] = useState(200000000);
  const [selectedRooms, setSelectedRooms] = useState<string[]>([]);

  const propertiesQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, "properties"), orderBy("createdAt", "desc"));
  }, [db]);

  const { data: properties, loading } = useCollection(propertiesQuery);

  const roomOptions = ["F2", "F3", "F4", "F5+"];

  const toggleRoomFilter = (room: string) => {
    setSelectedRooms(prev => 
      prev.includes(room) ? prev.filter(r => r !== room) : [...prev, room]
    );
  };

  const filteredProperties = useMemo(() => {
    if (!properties) return [];
    
    const sorted = [...properties].sort((a, b) => {
      if (a.isFeatured === b.isFeatured) return 0;
      return a.isFeatured ? -1 : 1;
    });

    return sorted.filter(p => {
      const matchesType = activeType === "all" || p.transactionType === activeType;
      const matchesSearch = (p.location || "").toLowerCase().includes(searchQuery.toLowerCase()) || 
                           (p.title || "").toLowerCase().includes(searchQuery.toLowerCase());
      const matchesPrice = Number(p.price) <= maxPrice;
      const matchesRooms = selectedRooms.length === 0 || 
                          selectedRooms.some(r => {
                            if (r === "F5+") return Number(p.bedrooms) >= 5;
                            return p.roomType === r;
                          });
      
      return matchesType && matchesSearch && matchesPrice && matchesRooms;
    });
  }, [properties, activeType, searchQuery, maxPrice, selectedRooms]);

  return (
    <div className="min-h-screen bg-background relative">
      <Navbar />
      
      <Link 
        href="/add" 
        className={`fixed bottom-8 ${t.dir === 'rtl' ? 'left-8' : 'right-8'} z-50 flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 bg-primary text-primary-foreground rounded-full shadow-[0_20px_40px_rgba(var(--primary),0.4)] hover:scale-110 active:scale-95 transition-all duration-300 border-4 border-accent/20 group`}
      >
        <Plus className="w-8 h-8 sm:w-10 sm:h-10 transition-transform group-hover:rotate-90" />
        <span className={`absolute ${t.dir === 'rtl' ? 'right-full mr-4' : 'left-full ml-4'} whitespace-nowrap bg-primary px-4 py-2 rounded-xl text-sm font-black opacity-0 group-hover:opacity-100 transition-opacity hidden sm:block`}>
          {t.hero.addBtn}
        </span>
      </Link>

      <section className="relative min-h-[500px] flex items-center justify-center overflow-hidden py-16">
        <div className="absolute inset-0 z-0">
          <Image
            src={PlaceHolderImages.find(img => img.id === 'hero-bg')?.imageUrl || "https://picsum.photos/seed/darihero/1200/600"}
            alt="Hero"
            fill
            className="object-cover brightness-[0.35]"
            priority
            data-ai-hint="luxury property"
          />
        </div>
        
        <div className="container relative z-10 mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center space-y-10">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-6xl font-bold font-headline text-white animate-in fade-in slide-in-from-bottom-4 duration-700 tracking-tight leading-tight">
                {t.hero.title}
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto font-medium">
                {t.hero.subtitle}
              </p>
            </div>
            
            <div className="flex flex-col gap-6 items-center w-full animate-in fade-in slide-in-from-bottom-8 duration-1000">
              {/* زر إضافة عقار الكبير والاحترافي */}
              <Button asChild className="h-20 px-12 rounded-[2rem] text-2xl font-black bg-primary hover:scale-105 transition-all shadow-2xl shadow-primary/40 border-4 border-accent/20">
                <Link href="/add" className="flex items-center gap-4">
                  <Sparkles className="w-8 h-8 text-accent animate-pulse" />
                  {t.hero.addBtn}
                </Link>
              </Button>

              <div className="w-full max-w-3xl bg-card/90 p-3 rounded-[2rem] shadow-2xl backdrop-blur-xl flex flex-col md:flex-row gap-3 items-center border border-white/10">
                <div className="flex-1 w-full relative group">
                  <Search className={`absolute ${t.dir === 'rtl' ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5 group-focus-within:text-primary transition-colors`} />
                  <Input 
                    className={`${t.dir === 'rtl' ? 'pr-12' : 'pl-12'} h-14 rounded-2xl border-none bg-secondary/30 focus-visible:ring-primary text-lg font-medium`} 
                    placeholder={t.hero.searchPlaceholder}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="h-14 px-6 rounded-2xl w-full md:w-auto gap-3 border-secondary bg-secondary/20 hover:bg-secondary/40">
                      <SlidersHorizontal className="w-5 h-5 text-primary" />
                      <span className="font-bold">{t.hero.filter}</span>
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-85 p-6 rounded-[2rem] shadow-2xl border-none bg-card/95 backdrop-blur-xl">
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <h4 className="font-black text-xl text-primary">{t.hero.filter}</h4>
                        <Button variant="ghost" size="sm" onClick={() => {
                          setSelectedRooms([]);
                          setMaxPrice(200000000);
                        }} className="text-xs h-8 text-destructive hover:bg-destructive/10">إعادة تعيين</Button>
                      </div>
                      
                      <div className="space-y-3">
                        <Label className="text-sm font-black opacity-70">نوع الشقة</Label>
                        <div className="grid grid-cols-2 gap-2">
                          {roomOptions.map(room => (
                            <button
                              key={room}
                              onClick={() => toggleRoomFilter(room)}
                              className={`flex items-center justify-between px-4 py-3 rounded-xl border-2 text-sm font-black transition-all ${
                                selectedRooms.includes(room) 
                                ? 'bg-primary text-primary-foreground border-primary shadow-lg scale-[1.02]' 
                                : 'bg-secondary/20 border-transparent hover:border-primary/30'
                              }`}
                            >
                              {room}
                              {selectedRooms.includes(room) && <Check className="w-4 h-4" />}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <Label className="text-sm font-black opacity-70">السعر الأقصى</Label>
                          <span className="text-sm font-black text-primary">{formatAlgerianCurrency(maxPrice, language)}</span>
                        </div>
                        <Slider
                          defaultValue={[maxPrice]}
                          max={200000000}
                          step={1000000}
                          onValueChange={(vals) => setMaxPrice(vals[0])}
                          className="py-4"
                        />
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>

                <Button className="h-14 px-10 rounded-2xl w-full md:w-auto text-lg font-black shadow-xl bg-primary text-primary-foreground hover:scale-105 transition-transform">
                  {t.hero.search}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8 mb-12">
            <div className="flex bg-secondary/30 p-2 rounded-[1.5rem] w-full md:w-auto shadow-inner border border-primary/5">
              <button 
                onClick={() => setActiveType("all")}
                className={`flex-1 md:flex-none px-8 py-3 rounded-xl text-base font-black transition-all ${activeType === 'all' ? 'bg-primary text-primary-foreground shadow-lg' : 'text-muted-foreground hover:bg-secondary'}`}
              >
                {t.home.all}
              </button>
              <button 
                onClick={() => setActiveType("rent")}
                className={`flex-1 md:flex-none px-8 py-3 rounded-xl text-base font-black transition-all ${activeType === 'rent' ? 'bg-primary text-primary-foreground shadow-lg' : 'text-muted-foreground hover:bg-secondary'}`}
              >
                {t.property.rent}
              </button>
              <button 
                onClick={() => setActiveType("sale")}
                className={`flex-1 md:flex-none px-8 py-3 rounded-xl text-base font-black transition-all ${activeType === 'sale' ? 'bg-primary text-primary-foreground shadow-lg' : 'text-muted-foreground hover:bg-secondary'}`}
              >
                {t.property.sale}
              </button>
            </div>
            
            <div className="text-sm font-black text-primary bg-primary/10 px-5 py-2 rounded-full border border-primary/20">
              {t.home.found.replace('{count}', filteredProperties.length.toString())}
            </div>
          </div>

          {loading ? (
            <div className="flex flex-col items-center justify-center py-24">
              <Loader2 className="w-12 h-12 animate-spin text-primary mb-4" />
              <p className="text-muted-foreground font-black">{t.home.loading}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {filteredProperties.map(property => (
                <PropertyCard 
                  key={property.id} 
                  id={property.id}
                  title={property.title}
                  type={property.transactionType as any}
                  price={property.price}
                  location={property.location}
                  bedrooms={property.bedrooms}
                  bathrooms={property.bathrooms}
                  area={property.areaSqM}
                  roomType={property.roomType}
                  imageUrl={property.imageUrl || PlaceHolderImages[0].imageUrl}
                  ownerPhone={property.ownerPhone}
                  latitude={property.latitude}
                  longitude={property.longitude}
                  ownerUid={property.ownerUid}
                  views={property.views}
                  isFeatured={property.isFeatured}
                />
              ))}
            </div>
          )}

          {!loading && filteredProperties.length === 0 && (
            <div className="text-center py-32 bg-secondary/5 rounded-[3rem] border-2 border-dashed border-muted">
              <div className="w-20 h-20 bg-muted/30 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="text-2xl font-black mb-2 text-primary/70">{t.home.noResults}</h3>
              <p className="text-muted-foreground max-w-md mx-auto font-medium">{t.home.noResultsSub}</p>
            </div>
          )}
        </div>
      </section>

      <footer className="bg-card border-t py-12">
        <div className="container mx-auto px-6 text-center">
          <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary mx-auto mb-6">
            <HomeIcon className="w-8 h-8" />
          </div>
          <p className="text-primary font-black text-lg mb-1">داري | DARI</p>
          <p className="text-muted-foreground font-bold text-sm">© {new Date().getFullYear()} - جميع الحقوق محفوظة</p>
        </div>
      </footer>
    </div>
  );
}
