
import type {Metadata, Viewport} from 'next';
import './globals.css';
import { FirebaseClientProvider } from '@/firebase';
import { Toaster } from '@/components/ui/toaster';
import { LanguageProvider } from '@/context/language-context';
import { RootLayoutInner } from './layout-inner';

export const metadata: Metadata = {
  title: 'داري | DARI - أكبر منصة عقارات في الجزائر',
  description: 'ابحث عن منزل أحلامك، شقة للكراء أو البيع، أراضي وفيلات في جميع ولايات الجزائر. منصة داري تجمعك بأصحاب العقارات مباشرة.',
  keywords: 'عقارات الجزائر, شقق للكراء الجزائر, بيع شقق الجزائر, واد كنيس عقارات, داري الجزائر, Real Estate Algeria',
  authors: [{ name: 'Dari Team' }],
  openGraph: {
    title: 'داري | DARI - عقارات الجزائر',
    description: 'تصفح آلاف العقارات المتاحة للبيع والكراء في الجزائر بكل سهولة.',
    url: 'https://dari-dz.web.app',
    siteName: 'Dari Algeria',
    images: [
      {
        url: 'https://picsum.photos/seed/dari/1200/630',
        width: 1200,
        height: 630,
      },
    ],
    locale: 'ar_DZ',
    type: 'website',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#4a3728',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <LanguageProvider>
      <RootLayoutInner>
        <FirebaseClientProvider>
          {children}
          <Toaster />
        </FirebaseClientProvider>
      </RootLayoutInner>
    </LanguageProvider>
  );
}
