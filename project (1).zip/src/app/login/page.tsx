
"use client"

import { useState, Suspense } from "react";
import { Navbar } from "@/components/navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Home, Phone, ArrowLeft, Loader2, Languages } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/context/language-context";
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup,
  signInAnonymously
} from "firebase/auth";
import { useFirestore } from "@/firebase";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";

function LoginContent() {
  const { t, language, setLanguage } = useLanguage();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const db = useFirestore();
  const auth = getAuth();
  
  const [loading, setLoading] = useState(false);
  const [loginMethod, setLoginMethod] = useState<"choice" | "phone" | "otp">("choice");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");

  const redirectUrl = searchParams.get("redirect") || "/";

  const syncUserProfile = async (user: any, phoneNum?: string) => {
    if (!db) return;
    
    const cleanPhone = phoneNum?.replace(/\s/g, '') || "";
    const isSuperAdmin = 
      user.email === "dgafrizinedine2002@gmail.com" || 
      user.phoneNumber === "+213781291214" || 
      cleanPhone === "0781291214" ||
      cleanPhone === "781291214" ||
      cleanPhone === "+213781291214";

    try {
      const userRef = doc(db, "users", user.uid);
      await setDoc(userRef, {
        uid: user.uid,
        displayName: user.displayName || (cleanPhone ? `User ${cleanPhone.slice(-4)}` : "User"),
        email: user.email || null,
        phoneNumber: user.phoneNumber || (cleanPhone.startsWith('+') ? cleanPhone : (cleanPhone ? `+213${cleanPhone.replace(/^0/, '')}` : null)),
        photoURL: user.photoURL || null,
        lastLogin: serverTimestamp(),
        isAdmin: isSuperAdmin, 
        isBanned: false,
        createdAt: user.metadata?.creationTime ? new Date(user.metadata.creationTime) : serverTimestamp(),
      }, { merge: true });
    } catch (e) {
      console.error("Error syncing user profile:", e);
    }
  };

  const handleGoogleLogin = async () => {
    if (loading) return;
    setLoading(true);
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      await syncUserProfile(result.user);
      
      toast({ 
        title: language === 'ar' ? "تم الدخول بنجاح" : "Login Successful", 
        description: `${language === 'ar' ? 'مرحباً' : 'Welcome'}, ${result.user.displayName}` 
      });
      
      router.replace(redirectUrl);
    } catch (error: any) {
      toast({ 
        variant: "destructive", 
        title: language === 'ar' ? "فشل الدخول" : "Login Failed", 
        description: error.message 
      });
      setLoading(false);
    }
  };

  const handleSendCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    
    if (phone.length < 9) {
      toast({ 
        variant: "destructive", 
        title: language === 'ar' ? "رقم غير صحيح" : "Invalid Number", 
        description: language === 'ar' ? "يرجى إدخال رقم هاتف صحيح." : "Please enter a valid phone number." 
      });
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setLoginMethod("otp");
      toast({ 
        title: language === 'ar' ? "تم إرسال الرمز" : "Code Sent", 
        description: language === 'ar' ? "رمز التحقق هو 123456" : "Your verification code is 123456" 
      });
    }, 600);
  };

  const handleVerify = async (e: React.FormEvent) => {
    if (e) e.preventDefault();
    if (loading) return;

    if (otp !== "123456") {
      toast({ 
        variant: "destructive", 
        title: language === 'ar' ? "رمز خاطئ" : "Invalid Code", 
        description: language === 'ar' ? "الرمز الذي أدخلته غير صحيح." : "The code you entered is incorrect." 
      });
      return;
    }

    setLoading(true);
    try {
      // استخدام signInAnonymously لإنشاء جلسة حقيقية للمحاكاة
      const authResult = await signInAnonymously(auth);
      const user = authResult.user;

      const mockUser = {
        uid: user.uid,
        displayName: `User ${phone.slice(-4)}`,
        phoneNumber: phone.startsWith('+') ? phone : `+213${phone.replace(/^0/, '')}`,
        email: null,
        photoURL: null,
        metadata: { creationTime: new Date().toISOString() }
      };
      
      await syncUserProfile(mockUser, phone);
      
      toast({ 
        title: language === 'ar' ? "تم التحقق" : "Verified", 
        description: language === 'ar' ? "جاري التوجيه..." : "Redirecting..." 
      });
      
      // التوجيه فوراً
      router.replace(redirectUrl);
    } catch (error: any) {
      console.error("Verification error:", error);
      toast({ 
        variant: "destructive", 
        title: "Error", 
        description: error.message || "فشل التحقق" 
      });
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-12">
      <Navbar />
      
      <div className="container mx-auto px-4 flex items-center justify-center pt-20">
        <Card className="w-full max-w-md border-none shadow-[0_30px_70px_rgba(0,0,0,0.15)] overflow-hidden rounded-[3rem] bg-card/80 backdrop-blur-xl">
          <div className="h-2 bg-gradient-to-r from-primary via-accent to-primary w-full" />
          <CardHeader className="text-center pt-12">
            <div className="w-24 h-24 bg-primary/10 rounded-[2rem] flex items-center justify-center text-primary mx-auto mb-8 shadow-inner rotate-3">
              <Home className="w-12 h-12" />
            </div>
            <CardTitle className="text-4xl font-headline font-black text-primary tracking-tight">{t.login.welcome}</CardTitle>
            <CardDescription className="text-lg font-medium opacity-70">
              {loginMethod === "otp" ? t.login.otpLogin : (language === 'ar' ? 'اختر وسيلة الدخول المفضلة' : 'Choose your login method')}
            </CardDescription>
          </CardHeader>
          <CardContent className="px-10 pb-12">
            {loginMethod === "choice" && (
              <div className="space-y-5">
                <Button 
                  onClick={handleGoogleLogin} 
                  disabled={loading} 
                  variant="outline" 
                  className="w-full h-16 rounded-2xl text-xl font-bold flex items-center justify-center gap-4 border-2 hover:bg-secondary/50 transition-all bg-card"
                >
                  <svg className="w-8 h-8" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  {t.login.googleLogin}
                </Button>
                
                <div className="relative my-8">
                  <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-primary/10"></span></div>
                  <div className="relative flex justify-center text-xs uppercase"><span className="bg-background px-2 text-muted-foreground font-black">{language === 'ar' ? 'أو' : 'OR'}</span></div>
                </div>

                <Button 
                  onClick={() => setLoginMethod("phone")} 
                  className="w-full h-16 rounded-2xl text-xl font-black flex items-center justify-center gap-4 shadow-2xl shadow-primary/30 bg-primary text-primary-foreground hover:scale-[1.02] transition-transform"
                >
                  <Phone className="w-8 h-8" />
                  {t.login.phoneLogin}
                </Button>
              </div>
            )}

            {loginMethod === "phone" && (
              <form onSubmit={handleSendCode} className="space-y-8">
                <Button variant="ghost" type="button" size="sm" onClick={() => setLoginMethod("choice")} className="gap-2 -ml-2 text-primary font-black text-lg">
                  <ArrowLeft className="w-6 h-6" /> {t.add.prev}
                </Button>
                <div className="space-y-3">
                  <Label htmlFor="phone" className="text-lg font-black">{t.login.phoneLabel}</Label>
                  <div className="relative">
                    <span className={`absolute ${t.dir === 'rtl' ? 'right-5' : 'left-5'} top-1/2 -translate-y-1/2 text-primary font-black border-${t.dir === 'rtl' ? 'l' : 'r'} ${t.dir === 'rtl' ? 'pl-4' : 'pr-4'} ltr text-xl`}>
                      +213
                    </span>
                    <Input 
                      id="phone" 
                      type="tel" 
                      placeholder="0XXXXXXXXX" 
                      className={`${t.dir === 'rtl' ? 'pr-20' : 'pl-20'} h-16 rounded-2xl text-xl font-black bg-secondary/30 border-none focus-visible:ring-primary shadow-inner`}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <Button disabled={loading} type="submit" className="w-full h-16 rounded-2xl text-xl font-black shadow-2xl shadow-primary/30 bg-primary text-primary-foreground">
                  {loading ? <Loader2 className="w-8 h-8 animate-spin" /> : t.login.sendCode}
                </Button>
              </form>
            )}

            {loginMethod === "otp" && (
              <form onSubmit={handleVerify} className="space-y-8">
                <div className="space-y-4 text-center">
                  <Label htmlFor="otp" className="text-muted-foreground font-black uppercase tracking-widest text-sm">{language === 'ar' ? 'رمز التحقق' : 'Verification Code'}</Label>
                  <Input 
                    id="otp" 
                    type="text" 
                    maxLength={6}
                    placeholder="------" 
                    className="h-20 rounded-2xl text-center text-4xl tracking-[0.6em] font-black bg-secondary/30 border-none shadow-inner text-primary"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    required
                    autoFocus
                  />
                  <p className="text-lg text-muted-foreground mt-6 font-medium">
                    {t.login.sentTo} <span className="text-primary font-black">{phone}</span>
                  </p>
                </div>
                <Button disabled={loading} type="submit" className="w-full h-16 rounded-2xl text-xl font-black shadow-2xl shadow-primary/30 bg-primary text-primary-foreground">
                  {loading ? <Loader2 className="w-8 h-8 animate-spin" /> : t.login.verify}
                </Button>
                <button type="button" onClick={() => { setLoginMethod("phone"); setOtp(""); }} className="w-full text-lg text-primary font-black hover:underline transition-all">
                  {t.login.changePhone}
                </button>
              </form>
            )}
            
            <div className="mt-16 pt-10 border-t border-primary/10">
              <h4 className="text-base font-black text-center text-primary/60 mb-8 flex items-center justify-center gap-3">
                <Languages className="w-6 h-6" /> {t.login.languageSelect}
              </h4>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'ar', label: 'العربية' },
                  { id: 'fr', label: 'Français' },
                  { id: 'en', label: 'English' }
                ].map((lang) => (
                  <button
                    key={lang.id}
                    type="button"
                    onClick={() => setLanguage(lang.id as any)}
                    className={`flex flex-col items-center justify-center p-5 rounded-[1.5rem] border-2 transition-all ${language === lang.id ? 'bg-primary text-primary-foreground border-primary shadow-2xl scale-110' : 'bg-secondary/20 border-transparent hover:border-primary/40'}`}
                  >
                    <span className="text-xs font-black uppercase mb-1 opacity-60">{lang.id}</span>
                    <span className="text-sm font-black">{lang.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
          <CardFooter className="bg-primary/5 p-8 flex flex-col gap-4 text-center">
            <p className="text-xs text-muted-foreground leading-relaxed px-6 font-bold">
              {t.login.terms}
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="h-screen flex items-center justify-center"><Loader2 className="animate-spin text-primary w-10 h-10" /></div>}>
      <LoginContent />
    </Suspense>
  );
}
