
"use client"

import { useMemo, useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { Navbar } from "@/components/navbar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Bed, 
  Bath, 
  Square, 
  MapPin, 
  Phone, 
  MessageCircle, 
  Send, 
  ArrowLeft, 
  Eye, 
  Star,
  CheckCircle2,
  Calendar,
  Building2,
  ChevronRight,
  ChevronLeft
} from "lucide-react";
import { useDoc, useFirestore, useUser } from "@/firebase";
import { doc, updateDoc, increment } from "firebase/firestore";
import { useLanguage } from "@/context/language-context";
import { formatAlgerianCurrency } from "@/lib/currency-formatter";
import Image from "next/image";

export default function PropertyDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const { t, language } = useLanguage();
  const { user } = useUser();
  const db = useFirestore();
  const id = params.id as string;
  
  const [activeImageIdx, setActiveImageIdx] = useState(0);

  const propertyRef = useMemo(() => {
    if (!db || !id) return null;
    return doc(db, "properties", id);
  }, [db, id]);

  const { data: property, loading } = useDoc(propertyRef as any);

  useEffect(() => {
    if (db && id && property && user?.uid !== property.ownerUid) {
      const ref = doc(db, "properties", id);
      updateDoc(ref, {
        views: increment(1)
      });
    }
  }, [db, id, property, user?.uid]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 text-center">
        <h1 className="text-4xl font-black text-primary mb-4">404</h1>
        <p className="text-muted-foreground mb-8">العقار غير موجود أو تم حذفه</p>
        <Button onClick={() => router.push("/")} className="rounded-2xl h-14 px-8 font-black">العودة للرئيسية</Button>
      </div>
    );
  }

  const images = property.images && property.images.length > 0 ? property.images : [property.imageUrl || "https://picsum.photos/seed/dari/1200/800"];
  const formattedPrice = formatAlgerianCurrency(Number(property.price), language);
  const phoneToUse = property.ownerPhone || "0555000000";
  const formattedPhone = phoneToUse.startsWith('0') ? '213' + phoneToUse.substring(1) : phoneToUse;

  const handleCall = () => window.open(`tel:${phoneToUse}`, '_self');
  const handleWhatsApp = () => window.open(`https://wa.me/${formattedPhone}`, '_blank');
  const handleViber = () => window.open(`viber://add?number=${formattedPhone}`, '_blank');

  const nextImage = () => setActiveImageIdx((prev) => (prev + 1) % images.length);
  const prevImage = () => setActiveImageIdx((prev) => (prev - 1 + images.length) % images.length);

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      
      {/* قسم عرض الصور (Gallery) */}
      <div className="relative h-[50vh] md:h-[70vh] w-full bg-black group">
        <Image 
          src={images[activeImageIdx]} 
          alt={property.title} 
          fill 
          className="object-contain"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/40 via-transparent to-transparent pointer-events-none" />
        
        {/* أزرار التحكم في المعرض */}
        {images.length > 1 && (
          <>
            <button 
              onClick={prevImage}
              className={`absolute top-1/2 ${t.dir === 'rtl' ? 'right-4' : 'left-4'} -translate-y-1/2 w-12 h-12 rounded-full bg-white/20 backdrop-blur-md text-white flex items-center justify-center hover:bg-white/40 transition-all z-20`}
            >
              {t.dir === 'rtl' ? <ChevronRight className="w-6 h-6" /> : <ChevronLeft className="w-6 h-6" />}
            </button>
            <button 
              onClick={nextImage}
              className={`absolute top-1/2 ${t.dir === 'rtl' ? 'left-4' : 'right-4'} -translate-y-1/2 w-12 h-12 rounded-full bg-white/20 backdrop-blur-md text-white flex items-center justify-center hover:bg-white/40 transition-all z-20`}
            >
              {t.dir === 'rtl' ? <ChevronLeft className="w-6 h-6" /> : <ChevronRight className="w-6 h-6" />}
            </button>
            
            {/* مؤشرات الصور */}
            <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex gap-2 z-20">
              {images.map((_: any, idx: number) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIdx(idx)}
                  className={`h-2 rounded-full transition-all ${idx === activeImageIdx ? 'w-8 bg-primary shadow-lg' : 'w-2 bg-white/50'}`}
                />
              ))}
            </div>
          </>
        )}

        <div className="absolute top-6 left-6 right-6 flex justify-between items-start z-30 pointer-events-none">
          <Button 
            onClick={() => router.back()} 
            className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md hover:bg-white/40 text-white border-none pointer-events-auto shadow-lg"
          >
            {t.dir === 'rtl' ? <ChevronRight className="w-6 h-6" /> : <ChevronLeft className="w-6 h-6" />}
          </Button>
          
          <div className="flex flex-col gap-2 items-end pointer-events-auto">
            <Badge className={`${property.transactionType === 'sale' ? 'bg-primary text-white' : 'bg-accent text-accent-foreground'} text-lg font-black px-6 py-2 rounded-2xl shadow-xl`}>
              {property.transactionType === "sale" ? t.property.sale : t.property.rent}
            </Badge>
            {property.isFeatured && (
              <Badge className="bg-accent text-accent-foreground font-black px-4 py-1.5 rounded-xl shadow-lg flex items-center gap-2 animate-pulse">
                <Star className="w-4 h-4 fill-current" />
                {t.property.featured}
              </Badge>
            )}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 -mt-24 relative z-40">
        {/* صور مصغرة (Thumbnails) */}
        <div className="flex gap-4 mb-8 overflow-x-auto pb-4 no-scrollbar">
          {images.map((img: string, idx: number) => (
            <button
              key={idx}
              onClick={() => setActiveImageIdx(idx)}
              className={`relative w-24 h-24 rounded-2xl overflow-hidden shrink-0 transition-all border-4 ${idx === activeImageIdx ? 'border-primary scale-110 shadow-xl' : 'border-white/20 opacity-70'}`}
            >
              <Image src={img} alt="" fill className="object-cover" />
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <Card className="rounded-[3rem] border-none shadow-[0_30px_60px_rgba(0,0,0,0.12)] overflow-hidden bg-card/80 backdrop-blur-xl">
              <CardContent className="p-8 md:p-12 space-y-8">
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-4 text-sm font-black text-primary/60 uppercase tracking-widest">
                    <span className="flex items-center gap-2"><Building2 className="w-4 h-4" /> {property.propertyType === 'apartment' ? t.add.apartment : t.add.house}</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-primary/20" />
                    <span className="flex items-center gap-2"><Calendar className="w-4 h-4" /> {new Date(property.createdAt?.seconds * 1000 || Date.now()).toLocaleDateString()}</span>
                    {(user?.uid === property.ownerUid || user?.email === "dgafrizinedine2002@gmail.com") && (
                      <span className="flex items-center gap-2 text-accent"><Eye className="w-4 h-4" /> {property.views} {t.property.views}</span>
                    )}
                  </div>
                  <h1 className="text-3xl md:text-5xl font-black text-primary tracking-tight leading-tight">{property.title}</h1>
                  <div className="flex items-center gap-3 text-lg text-muted-foreground font-medium">
                    <MapPin className="w-6 h-6 text-accent" />
                    {property.location}
                  </div>
                </div>

                <div className="bg-primary/5 p-8 rounded-[2.5rem] flex flex-col md:flex-row md:items-center justify-between gap-6 border border-primary/10">
                  <div className="space-y-1">
                    <p className="text-sm font-black text-primary/40 uppercase tracking-widest">{t.add.price}</p>
                    <p className="text-4xl md:text-5xl font-black text-primary">{formattedPrice}</p>
                  </div>
                  <div className="grid grid-cols-3 gap-6 md:gap-12">
                    <div className="text-center">
                      <Bed className="w-8 h-8 text-primary/60 mx-auto mb-2" />
                      <p className="text-sm font-black">{property.bedrooms} {t.property.rooms}</p>
                    </div>
                    <div className="text-center">
                      <Bath className="w-8 h-8 text-primary/60 mx-auto mb-2" />
                      <p className="text-sm font-black">{property.bathrooms} {t.property.bath}</p>
                    </div>
                    <div className="text-center">
                      <Square className="w-8 h-8 text-primary/60 mx-auto mb-2" />
                      <p className="text-sm font-black">{property.areaSqM} m²</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <h3 className="text-2xl font-black text-primary">{t.property.description}</h3>
                  <div className="text-lg leading-relaxed text-muted-foreground font-medium whitespace-pre-wrap bg-secondary/10 p-8 rounded-[2rem] shadow-inner">
                    {property.description}
                  </div>
                </div>

                {property.amenities && property.amenities.length > 0 && (
                  <div className="space-y-6">
                    <h3 className="text-2xl font-black text-primary">{t.property.amenities}</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                      {property.amenities.map((amenity: string, idx: number) => (
                        <div key={idx} className="flex items-center gap-3 p-4 bg-secondary/20 rounded-2xl border border-transparent hover:border-primary/20 transition-all">
                          <CheckCircle2 className="w-5 h-5 text-primary" />
                          <span className="font-black text-sm">{amenity}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="rounded-[2.5rem] border-none shadow-2xl bg-primary text-primary-foreground overflow-hidden sticky top-24">
              <CardContent className="p-8 space-y-8">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center font-black text-2xl">
                    {property.ownerPhone?.[0] || 'D'}
                  </div>
                  <div>
                    <h4 className="font-black text-xl">{t.property.owner}</h4>
                    <p className="opacity-70 font-medium">عضو موثوق في داري</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <Button 
                    onClick={handleCall}
                    className="w-full h-16 rounded-2xl bg-white text-primary hover:bg-white/90 text-xl font-black shadow-xl gap-4"
                  >
                    <Phone className="w-6 h-6" />
                    {t.property.call}
                  </Button>
                  <Button 
                    onClick={handleWhatsApp}
                    variant="outline"
                    className="w-full h-16 rounded-2xl border-white/20 bg-white/10 hover:bg-white/20 text-white text-xl font-black gap-4"
                  >
                    <MessageCircle className="w-6 h-6" />
                    {t.property.whatsapp}
                  </Button>
                  <Button 
                    onClick={handleViber}
                    variant="outline"
                    className="w-full h-16 rounded-2xl border-white/20 bg-white/10 hover:bg-white/20 text-white text-xl font-black gap-4"
                  >
                    <Send className="w-6 h-6" />
                    {t.property.viber}
                  </Button>
                </div>
                
                <p className="text-center text-xs opacity-60 font-medium">
                  نرجو إبلاغ صاحب العقار أنك وجدت الإعلان على تطبيق داري
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
