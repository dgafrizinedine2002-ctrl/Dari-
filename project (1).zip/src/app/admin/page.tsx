
"use client"

import { useState, useMemo, useEffect } from "react";
import { Navbar } from "@/components/navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useCollection, useUser, useDoc, useFirestore } from "@/firebase";
import { collection, query, orderBy, deleteDoc, doc, updateDoc } from "firebase/firestore";
import { useLanguage } from "@/context/language-context";
import { Loader2, Users, Building, Trash2, Pin, PinOff, ShieldAlert, ShieldCheck, ArrowLeft } from "lucide-react";
import { useRouter } from "next/navigation";
import Image from "next/image";

export default function AdminPage() {
  const { t } = useLanguage();
  const { user, loading: authLoading } = useUser();
  const db = useFirestore();
  const router = useRouter();
  
  const userProfileRef = user && db ? doc(db, "users", user.uid) : null;
  const { data: userProfile, loading: profileLoading } = useDoc(userProfileRef as any);
  
  const propertiesQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, "properties"), orderBy("createdAt", "desc"));
  }, [db]);

  const usersQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, "users"), orderBy("createdAt", "desc"));
  }, [db]);

  const { data: properties, loading: propsLoading } = useCollection(propertiesQuery);
  const { data: users, loading: usersLoading } = useCollection(usersQuery);

  const stats = useMemo(() => {
    if (!properties || !users) return { totalUsers: 0, rent: 0, sale: 0 };
    return {
      totalUsers: users.length,
      rent: properties.filter(p => p.transactionType === 'rent').length,
      sale: properties.filter(p => p.transactionType === 'sale').length
    };
  }, [properties, users]);

  // منطق التحقق من المشرف الخارق المخصص
  const isAdmin = 
    userProfile?.isAdmin || 
    user?.email === "dgafrizinedine2002@gmail.com" || 
    user?.phoneNumber === "+213781291214";

  useEffect(() => {
    if (!authLoading && !profileLoading) {
      if (!user || !isAdmin) {
        console.warn("Unauthorized access attempt to Admin Dashboard.");
      }
    }
  }, [user, isAdmin, authLoading, profileLoading]);

  if (authLoading || profileLoading) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-background">
        <Loader2 className="animate-spin w-12 h-12 text-primary mb-4" />
        <p className="font-black text-primary animate-pulse">جاري التحقق من الصلاحيات...</p>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 text-center">
        <div className="w-24 h-24 bg-destructive/10 rounded-[2rem] flex items-center justify-center text-destructive mb-8 shadow-inner">
          <ShieldAlert className="w-12 h-12" />
        </div>
        <h1 className="text-4xl font-black mb-4 text-primary tracking-tight">الدخول ممنوع</h1>
        <p className="text-muted-foreground mb-10 text-lg font-medium max-w-md">عذراً، لا تمتلك صلاحيات المشرف للوصول إلى هذه اللوحة الحساسة.</p>
        <Button 
          onClick={() => router.push("/")} 
          className="rounded-2xl h-16 px-10 bg-primary text-xl font-black shadow-xl shadow-primary/20 hover:scale-105 transition-all"
        >
          <ArrowLeft className="mr-2" /> العودة للرئيسية
        </Button>
      </div>
    );
  }

  const handleDeleteProperty = async (id: string) => {
    if (!db || !confirm(t.admin.confirmDelete)) return;
    await deleteDoc(doc(db, "properties", id));
  };

  const toggleFeature = async (id: string, current: boolean) => {
    if (!db) return;
    await updateDoc(doc(db, "properties", id), { isFeatured: !current });
  };

  const toggleBan = async (id: string, current: boolean) => {
    if (!db) return;
    await updateDoc(doc(db, "users", id), { isBanned: !current });
  };

  return (
    <div className="min-h-screen bg-secondary/10">
      <Navbar />
      <div className="container mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-4xl font-black text-primary tracking-tight">{t.admin.title}</h1>
            <p className="text-muted-foreground font-medium">مرحباً بك مجدداً في مركز القيادة</p>
          </div>
          <Button variant="outline" onClick={() => router.push("/")} className="rounded-2xl border-primary text-primary h-12 px-6 font-black">
            {t.nav.home}
          </Button>
        </div>

        <Tabs defaultValue="stats" className="space-y-8">
          <TabsList className="bg-card p-1 rounded-2xl h-14 w-full sm:w-auto shadow-sm border">
            <TabsTrigger value="stats" className="rounded-xl px-8 font-black data-[state=active]:bg-primary data-[state=active]:text-white h-12">
              الإحصائيات
            </TabsTrigger>
            <TabsTrigger value="properties" className="rounded-xl px-8 font-black data-[state=active]:bg-primary data-[state=active]:text-white h-12">
              العقارات
            </TabsTrigger>
            <TabsTrigger value="users" className="rounded-xl px-8 font-black data-[state=active]:bg-primary data-[state=active]:text-white h-12">
              المستخدمين
            </TabsTrigger>
          </TabsList>

          <TabsContent value="stats">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="rounded-[2rem] border-none shadow-lg bg-card overflow-hidden">
                <CardHeader className="bg-primary/5 pb-4">
                  <CardTitle className="flex items-center gap-3 text-lg font-black text-primary">
                    <Users className="w-6 h-6" /> {t.admin.totalUsers}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="text-5xl font-black text-primary">{stats.totalUsers}</div>
                </CardContent>
              </Card>
              <Card className="rounded-[2rem] border-none shadow-lg bg-card overflow-hidden">
                <CardHeader className="bg-primary/5 pb-4">
                  <CardTitle className="flex items-center gap-3 text-lg font-black text-primary">
                    <Building className="w-6 h-6" /> {t.admin.totalRent}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="text-5xl font-black text-primary">{stats.rent}</div>
                </CardContent>
              </Card>
              <Card className="rounded-[2rem] border-none shadow-lg bg-card overflow-hidden">
                <CardHeader className="bg-primary/5 pb-4">
                  <CardTitle className="flex items-center gap-3 text-lg font-black text-primary">
                    <Building className="w-6 h-6" /> {t.admin.totalSale}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="text-5xl font-black text-primary">{stats.sale}</div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="properties">
            <div className="space-y-4">
              {propsLoading ? <Loader2 className="animate-spin mx-auto text-primary" /> : properties?.map(p => (
                <Card key={p.id} className="rounded-[1.5rem] border-none shadow-sm overflow-hidden group hover:shadow-md transition-all">
                  <div className="flex flex-col sm:flex-row items-center gap-6 p-4">
                    <div className="relative w-full sm:w-32 h-24 rounded-xl overflow-hidden shrink-0">
                      <Image src={p.imageUrl || "https://picsum.photos/seed/dari/200/150"} alt="" fill className="object-cover" />
                    </div>
                    <div className="flex-1 text-center sm:text-left">
                      <h4 className="font-black text-lg text-primary">{p.title}</h4>
                      <p className="text-sm text-muted-foreground font-medium">{p.location} • {Number(p.price).toLocaleString()} DZD</p>
                      <div className="mt-2 flex flex-wrap justify-center sm:justify-start gap-2">
                         <Badge variant="secondary" className="bg-secondary/50 font-black">{p.transactionType === 'sale' ? t.property.sale : t.property.rent}</Badge>
                         {p.isFeatured && <Badge className="bg-accent text-accent-foreground font-black animate-pulse">★ {t.property.featured}</Badge>}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        onClick={() => toggleFeature(p.id, p.isFeatured)} 
                        size="sm" 
                        variant={p.isFeatured ? "secondary" : "outline"} 
                        className="rounded-xl h-12 w-12 p-0 border-2"
                        title={p.isFeatured ? t.admin.unpin : t.admin.pin}
                      >
                        {p.isFeatured ? <PinOff className="w-5 h-5 text-accent" /> : <Pin className="w-5 h-5 text-primary" />}
                      </Button>
                      <Button 
                        onClick={() => handleDeleteProperty(p.id)} 
                        size="sm" 
                        variant="destructive" 
                        className="rounded-xl h-12 w-12 p-0 shadow-lg shadow-destructive/10"
                        title={t.admin.delete}
                      >
                        <Trash2 className="w-5 h-5" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
              {properties?.length === 0 && <p className="text-center py-20 opacity-50 font-black">لا توجد عقارات حالياً</p>}
            </div>
          </TabsContent>

          <TabsContent value="users">
            <div className="space-y-4">
               {usersLoading ? <Loader2 className="animate-spin mx-auto text-primary" /> : users?.map(u => (
                <Card key={u.id} className="rounded-[1.5rem] border-none shadow-sm overflow-hidden hover:bg-card/50 transition-all">
                  <div className="flex items-center justify-between p-6">
                    <div className="flex items-center gap-4">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-xl shadow-sm ${u.isAdmin ? 'bg-primary text-white' : 'bg-secondary text-primary'}`}>
                        {u.displayName?.[0] || 'U'}
                      </div>
                      <div>
                        <h4 className="font-black text-lg text-primary">{u.displayName || 'مستخدم مجهول'}</h4>
                        <p className="text-xs text-muted-foreground font-bold">{u.email || u.phoneNumber || u.id}</p>
                        <div className="flex gap-2 mt-1">
                          {u.isBanned && <Badge variant="destructive" className="font-black">محظور</Badge>}
                          {u.isAdmin && <Badge className="bg-primary font-black">مشرف</Badge>}
                        </div>
                      </div>
                    </div>
                    <Button 
                      onClick={() => toggleBan(u.id, u.isBanned)} 
                      variant={u.isBanned ? "outline" : "destructive"} 
                      className="rounded-2xl h-12 px-6 font-black shadow-lg"
                      disabled={u.id === user?.uid}
                    >
                      {u.isBanned ? <ShieldCheck className="w-4 h-4 mr-2" /> : <ShieldAlert className="w-4 h-4 mr-2" />}
                      {u.isBanned ? t.admin.unban : t.admin.ban}
                    </Button>
                  </div>
                </Card>
              ))}
              {users?.length === 0 && <p className="text-center py-20 opacity-50 font-black">لا يوجد مستخدمون مسجلون</p>}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
