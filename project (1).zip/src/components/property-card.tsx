
"use client"

import Image from "next/image";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bed, Bath, Square, MapPin, Phone, MessageCircle, Map as MapIcon, Send, Eye, Star } from "lucide-react";
import { useLanguage } from "@/context/language-context";
import { useUser } from "@/firebase";
import { formatAlgerianCurrency } from "@/lib/currency-formatter";

interface PropertyCardProps {
  id: string;
  title: string;
  type: "rent" | "sale";
  price: string | number;
  location: string;
  bedrooms: number;
  bathrooms: number;
  area: number;
  imageUrl: string;
  roomType?: string;
  ownerPhone?: string;
  ownerUid?: string;
  views?: number;
  latitude?: number | null;
  longitude?: number | null;
  isFeatured?: boolean;
}

export function PropertyCard({
  id,
  title,
  type,
  price,
  location,
  bedrooms,
  bathrooms,
  area,
  imageUrl,
  roomType,
  ownerPhone,
  ownerUid,
  views = 0,
  latitude,
  longitude,
  isFeatured = false
}: PropertyCardProps) {
  const { t, language } = useLanguage();
  const { user } = useUser();
  
  const isOwner = user && user.uid === ownerUid;
  
  const phoneToUse = ownerPhone || "0555000000";
  const formattedPhone = phoneToUse.startsWith('0') ? '213' + phoneToUse.substring(1) : phoneToUse;

  const handleCall = (e: React.MouseEvent) => {
    e.stopPropagation();
    window.open(`tel:${phoneToUse}`, '_self');
  };

  const handleWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    window.open(`https://wa.me/${formattedPhone}`, '_blank');
  };

  const handleViber = (e: React.MouseEvent) => {
    e.stopPropagation();
    window.open(`viber://add?number=${formattedPhone}`, '_blank');
  };
  
  const handleMap = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (latitude && longitude) {
      window.open(`https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`, '_blank');
    } else {
      window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`, '_blank');
    }
  };

  const formattedPrice = formatAlgerianCurrency(Number(price), language);

  return (
    <Card className={`group overflow-hidden border-none shadow-md hover:shadow-2xl transition-all duration-300 bg-card rounded-[2rem] ${isFeatured ? 'ring-2 ring-accent' : ''}`}>
      <Link href={`/property/${id}`}>
        <div className="relative aspect-[4/3] overflow-hidden">
          <Image
            src={imageUrl}
            alt={title}
            fill
            className="object-cover transition-transform duration-700 group-hover:scale-110"
            data-ai-hint="property house apartment"
          />
          <div className={`absolute top-4 ${t.dir === 'rtl' ? 'left-4' : 'right-4'} flex flex-col gap-2`}>
            <Badge className={`${type === 'sale' ? 'bg-primary text-white' : 'bg-accent text-accent-foreground'} border-none font-black shadow-lg px-2 py-0.5 text-[10px] uppercase`}>
              {type === "sale" ? t.property.sale : t.property.rent}
            </Badge>
            {roomType && (
              <Badge variant="secondary" className="font-black bg-white/95 backdrop-blur-sm text-primary border-none shadow-sm px-2 py-0.5 text-[10px]">
                {roomType}
              </Badge>
            )}
          </div>

          {isFeatured && (
            <div className={`absolute top-4 ${t.dir === 'rtl' ? 'right-4' : 'left-4'}`}>
              <Badge className="bg-accent text-accent-foreground border-none font-black flex items-center gap-1.5 px-2 py-0.5 shadow-lg animate-pulse text-[10px]">
                <Star className="w-3 h-3 fill-current" />
                <span>{t.property.featured}</span>
              </Badge>
            </div>
          )}

          {isOwner && (
            <div className={`absolute bottom-4 ${t.dir === 'rtl' ? 'left-4' : 'right-4'}`}>
              <Badge className="bg-black/60 backdrop-blur-md text-white border-none font-black flex items-center gap-1.5 px-2 py-0.5 text-[10px]">
                <Eye className="w-3 h-3" />
                <span>{views} {t.property.views}</span>
              </Badge>
            </div>
          )}
          
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={handleMap}
            className={`absolute bottom-4 ${t.dir === 'rtl' ? 'right-4' : 'left-4'} gap-2 bg-white/95 backdrop-blur-md hover:bg-white text-primary rounded-xl shadow-lg border-none font-black h-8 px-3 transition-all`}
          >
            <MapIcon className="w-3.5 h-3.5" />
            <span className="text-[10px] uppercase tracking-tight">{t.property.map}</span>
          </Button>
        </div>
      </Link>
      
      <CardContent className="p-6">
        <Link href={`/property/${id}`}>
          <div className="flex justify-between items-start mb-1">
            <h3 className="font-headline font-black text-lg line-clamp-1 group-hover:text-primary transition-colors">{title}</h3>
          </div>
          <div className="flex items-baseline gap-1 mb-3 bg-primary/5 p-2 rounded-xl inline-block">
            <span className="text-primary text-xl font-black">{formattedPrice}</span>
          </div>
          
          <div className="flex items-center gap-2 text-muted-foreground text-[12px] mb-4 font-medium">
            <MapPin className="w-3.5 h-3.5 text-accent animate-pulse" />
            <span className="line-clamp-1">{location}</span>
          </div>
          
          <div className="grid grid-cols-3 gap-2 py-3 border-y border-border/50 bg-secondary/5 rounded-2xl mb-4">
            <div className="flex flex-col items-center gap-0.5">
              <Bed className="w-4 h-4 text-primary/70" />
              <span className="text-[10px] font-black">{bedrooms}</span>
            </div>
            <div className="flex flex-col items-center gap-0.5 border-x border-border/50">
              <Bath className="w-4 h-4 text-primary/70" />
              <span className="text-[10px] font-black">{bathrooms}</span>
            </div>
            <div className="flex flex-col items-center gap-0.5">
              <Square className="w-4 h-4 text-primary/70" />
              <span className="text-[10px] font-black">{area} m²</span>
            </div>
          </div>
        </Link>
      </CardContent>

      <CardFooter className="px-6 pb-6 pt-0 grid grid-cols-3 gap-2">
        <Button onClick={handleCall} size="sm" className="bg-primary hover:bg-primary/90 rounded-xl gap-1 shadow-lg shadow-primary/10 transition-all font-bold h-9">
          <Phone className="w-3.5 h-3.5" />
          <span className="text-[10px] uppercase font-black">{t.property.call}</span>
        </Button>
        <Button onClick={handleWhatsApp} size="sm" variant="outline" className="border-2 border-green-500/30 text-green-600 hover:bg-green-50 rounded-xl gap-1 shadow-sm transition-all font-bold h-9">
          <MessageCircle className="w-3.5 h-3.5" />
          <span className="text-[10px] uppercase font-black">WA</span>
        </Button>
        <Button onClick={handleViber} size="sm" variant="outline" className="border-2 border-purple-500/30 text-purple-600 hover:bg-purple-50 rounded-xl gap-1 shadow-sm transition-all font-bold h-9">
          <Send className="w-3.5 h-3.5" />
          <span className="text-[10px] uppercase font-black">VB</span>
        </Button>
      </CardFooter>
    </Card>
  );
}
