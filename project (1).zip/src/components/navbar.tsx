
"use client"

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { Home as HomeIcon, User, Moon, Sun, Settings, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/context/language-context";
import { useRouter } from "next/navigation";
import { useUser, useDoc } from "@/firebase";
import { doc } from "firebase/firestore";
import { useFirestore } from "@/firebase";
import { getAuth, signOut } from "firebase/auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Navbar() {
  const { t, language } = useLanguage();
  const router = useRouter();
  const { user } = useUser();
  const db = useFirestore();
  const auth = getAuth();
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);

  const userProfileRef = user && db ? doc(db, "users", user.uid) : null;
  const { data: userProfile } = useDoc(userProfileRef as any);
  
  // صلاحية المشرف الخارق المخصص: dgafrizinedine2002@gmail.com
  const isAdmin = 
    userProfile?.isAdmin || 
    user?.email === "dgafrizinedine2002@gmail.com" || 
    user?.phoneNumber === "+213781291214";

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") as "light" | "dark" | null;
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.classList.toggle("dark", savedTheme === "dark");
    } else if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
      setTheme("dark");
      document.documentElement.classList.add("dark");
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    document.documentElement.classList.toggle("dark", newTheme === "dark");
  };

  const handleLogout = async () => {
    await signOut(auth);
    router.push("/login");
  };

  const handleStartPress = () => {
    longPressTimer.current = setTimeout(() => {
      if (isAdmin) {
        router.push("/admin");
      }
    }, 2000);
  };

  const handleEndPress = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur-md shadow-sm h-20">
      <div className="container mx-auto px-4 h-full flex items-center justify-between">
        
        <div className="flex-1 flex justify-start items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={toggleTheme}
            className="rounded-full bg-secondary/50 hover:bg-secondary transition-all w-12 h-12 shadow-sm"
          >
            {theme === "light" ? (
              <Moon className="w-6 h-6 text-primary" />
            ) : (
              <Sun className="w-6 h-6 text-primary" />
            )}
          </Button>
          
          {isAdmin && (
             <Button asChild variant="ghost" size="icon" className="rounded-full bg-primary/10 hover:bg-primary/20 w-12 h-12">
               <Link href="/admin">
                 <Settings className="w-6 h-6 text-primary" />
               </Link>
             </Button>
          )}
        </div>

        <Link href="/" className="flex items-center gap-3 shrink-0">
          <div className="w-12 h-12 bg-primary rounded-[1rem] flex items-center justify-center text-primary-foreground shadow-lg rotate-3">
            <HomeIcon className="w-7 h-7" />
          </div>
          <span className="text-2xl md:text-3xl font-headline font-black text-primary tracking-tighter">
            {language === 'ar' ? 'داري | Dari' : 'Dari | داري'}
          </span>
        </Link>

        <div className="flex-1 flex justify-end items-center gap-3">
          {user ? (
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="icon" 
                className="rounded-full p-0 overflow-hidden w-12 h-12 border-2 border-primary/20"
                onMouseDown={handleStartPress}
                onMouseUp={handleEndPress}
                onTouchStart={handleStartPress}
                onTouchEnd={handleEndPress}
              >
                <Avatar className="w-full h-full">
                  <AvatarImage src={user.photoURL || ""} />
                  <AvatarFallback className="bg-primary text-white font-black">
                    {user.displayName?.[0] || user.email?.[0] || 'U'}
                  </AvatarFallback>
                </Avatar>
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleLogout}
                className="rounded-2xl bg-destructive/10 hover:bg-destructive/20 text-destructive w-10 h-10"
                title={language === 'ar' ? 'تسجيل الخروج' : 'Logout'}
              >
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          ) : (
            <Button 
              asChild 
              variant="ghost" 
              size="icon" 
              className="rounded-2xl bg-secondary/50 hover:bg-secondary w-12 h-12"
            >
              <Link href="/login">
                <User className="w-6 h-6 text-primary" />
              </Link>
            </Button>
          )}
        </div>
      </div>
    </nav>
  );
}
