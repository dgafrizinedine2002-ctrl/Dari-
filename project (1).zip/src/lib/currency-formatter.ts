
/**
 * دالة لتنسيق العملة حسب السوق الجزائري الدارج (سنتيم)
 * 1 دينار جزائري = 100 سنتيم
 * 10,000 دينار = 1 مليون سنتيم
 * 10,000,000 دينار = 1 مليار سنتيم
 */
export function formatAlgerianCurrency(priceDZD: number, lang: 'ar' | 'fr' | 'en' = 'ar'): string {
  if (!priceDZD || isNaN(priceDZD)) return lang === 'ar' ? '0 دج' : '0 DZD';

  // التحويل إلى ملايين السنتيم
  const millions = priceDZD / 10000;
  
  if (lang !== 'ar') {
    return priceDZD.toLocaleString() + ' DZD';
  }

  // التنسيق باللغة العربية الدارجة
  if (priceDZD >= 10000000) { // 1 مليار سنتيم فما فوق
    const milliards = Math.floor(priceDZD / 10000000);
    const remainingMillions = Math.floor((priceDZD % 10000000) / 10000);
    
    let result = milliards === 1 ? "1 مليار" : (milliards === 2 ? "2 مليارات" : `${milliards} ملايير`);
    if (remainingMillions > 0) {
      result += ` و ${remainingMillions} مليون`;
    }
    return result;
  } 
  
  if (priceDZD >= 10000) { // من 1 مليون سنتيم إلى أقل من مليار
    const integralMillions = Math.floor(millions);
    const remainingDZD = priceDZD % 10000;
    const miat = Math.floor(remainingDZD / 1000); // كل 1000 دج هي "مية" (100,000 سنتيم)
    
    let result = integralMillions === 1 ? "مليون" : (integralMillions === 2 ? "2 ملاين" : `${integralMillions} مليون`);
    if (miat > 0) {
      result += ` و ${miat} ميات`;
    }
    return result;
  }

  // أقل من مليون سنتيم
  const miat = Math.floor(priceDZD / 1000);
  if (miat > 0) {
    const remaining = priceDZD % 1000;
    let result = miat === 1 ? "مية" : `${miat} ميات`;
    if (remaining > 0) result += ` و ${remaining} دج`;
    return result;
  }

  return `${priceDZD} دج`;
}
