import {genkit} from 'genkit';
import {googleAI} from '@genkit-ai/google-genai';

// التحقق من وجود المفتاح لتجنب أخطاء بدء التشغيل في بعض البيئات
const apiKey = process.env.GOOGLE_GENAI_API_KEY || process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;

export const ai = genkit({
  plugins: [googleAI({apiKey})],
  model: 'googleai/gemini-2.5-flash',
});
