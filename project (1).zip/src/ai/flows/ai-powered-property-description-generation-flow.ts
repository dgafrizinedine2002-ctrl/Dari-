'use server';
/**
 * @fileOverview This file implements a Genkit flow for generating engaging property descriptions.
 *
 * - generatePropertyDescription - A function that generates a detailed property description.
 * - GeneratePropertyDescriptionInput - The input type for the generatePropertyDescription function.
 * - GeneratePropertyDescriptionOutput - The return type for the generatePropertyDescription function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GeneratePropertyDescriptionInputSchema = z.object({
  propertyType: z
    .string()
    .describe(
      'The type of property, e.g., apartment, house, villa, commercial, land.'
    ),
  transactionType: z
    .string()
    .describe('The type of transaction, e.g., rent or sale.'),
  location: z
    .string()
    .describe('The location of the property, e.g., "Algiers, Bab Ezzouar".'),
  bedrooms: z.number().int().min(0).describe('Number of bedrooms.'),
  bathrooms: z.number().int().min(0).describe('Number of bathrooms.'),
  areaSqM: z.number().min(1).describe('Area of the property in square meters.'),
  amenities: z
    .array(z.string())
    .describe(
      'A list of amenities available, e.g., ["gas", "water", "internet", "parking", "garden", "balcony"].'
    ),
  additionalFeatures: z
    .string()
    .optional()
    .describe('Any additional unique features or selling points of the property.'),
});
export type GeneratePropertyDescriptionInput = z.infer<
  typeof GeneratePropertyDescriptionInputSchema
>;

const GeneratePropertyDescriptionOutputSchema = z.object({
  description: z.string().describe('The generated engaging property description.'),
});
export type GeneratePropertyDescriptionOutput = z.infer<
  typeof GeneratePropertyDescriptionOutputSchema
>;

/**
 * دالة لتوليد وصف محلي احترافي في حال غياب مفتاح API
 */
function generateMockDescription(input: GeneratePropertyDescriptionInput): string {
  const { propertyType, transactionType, location, areaSqM, bedrooms, amenities, additionalFeatures } = input;
  const action = transactionType === 'rent' ? 'للكراء' : 'للبيع';
  
  const amenitiesList = amenities.length > 0 
    ? `\nالمميزات والمرافق:\n${amenities.map(a => `• ${a}`).join('\n')}` 
    : '';

  return `فرصة استثنائية! معروض ${action}: ${propertyType} فاخرة تقع في موقع استراتيجي بـ ${location}.
تتميز هذه المساحة بـ ${areaSqM} متر مربع من التصميم العصري والراحة التامة. 
تتكون من ${bedrooms} غرف واسعة ومشرحة، مما يجعلها مثالية للعائلات أو الأفراد الباحثين عن التميز.
${amenitiesList}
${additionalFeatures ? `\nإضافات مميزة: ${additionalFeatures}` : ''}

هذا العقار يجمع بين جودة البناء والموقع الحيوي القريب من كل المرافق. لا تفوتوا هذه الفرصة، اتصلوا بنا الآن للمعاينة!`;
}

export async function generatePropertyDescription(
  input: GeneratePropertyDescriptionInput
): Promise<GeneratePropertyDescriptionOutput> {
  // التحقق من وجود مفتاح API في البيئة
  const apiKey = process.env.GOOGLE_GENAI_API_KEY || process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;

  if (!apiKey) {
    console.warn("Gemini API Key is missing. Using local mock generator.");
    // محاكاة تأخير بسيط ليبدو وكأنه ذكاء اصطناعي
    await new Promise(resolve => setTimeout(resolve, 1500));
    return {
      description: generateMockDescription(input)
    };
  }

  try {
    return await generatePropertyDescriptionFlow(input);
  } catch (error) {
    console.error("AI Generation failed, falling back to mock:", error);
    return {
      description: generateMockDescription(input)
    };
  }
}

const propertyDescriptionPrompt = ai.definePrompt({
  name: 'propertyDescriptionPrompt',
  input: {schema: GeneratePropertyDescriptionInputSchema},
  output: {schema: GeneratePropertyDescriptionOutputSchema},
  prompt: `You are an expert real estate copywriter specializing in properties in Algeria.
Your task is to create a compelling, detailed, and engaging property description based on the provided information in ARABIC.
Highlight key features, amenities, and the overall appeal of the property.
Focus on creating a description that attracts potential buyers or renters.

Property Details:
- Type: {{{propertyType}}}
- Transaction: {{{transactionType}}}
- Location: {{{location}}}
- Bedrooms: {{{bedrooms}}}
- Bathrooms: {{{bathrooms}}}
- Area: {{{areaSqM}}} square meters
- Amenities: {{#if amenities}}{{#each amenities}}- {{{this}}}
{{/each}}{{else}}No specific amenities listed.{{/if}}
{{#if additionalFeatures}}- Additional Features: {{{additionalFeatures}}}{{/if}}

Generate a detailed and engaging property description for this listing in Arabic language. The description should be at least 150 words and be suitable for a high-end real estate listing.`,
});

const generatePropertyDescriptionFlow = ai.defineFlow(
  {
    name: 'generatePropertyDescriptionFlow',
    inputSchema: GeneratePropertyDescriptionInputSchema,
    outputSchema: GeneratePropertyDescriptionOutputSchema,
  },
  async input => {
    const {output} = await propertyDescriptionPrompt(input);
    if (!output) {
      throw new Error('Failed to generate property description.');
    }
    return output;
  }
);
