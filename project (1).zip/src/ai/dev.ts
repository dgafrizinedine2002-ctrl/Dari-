import { config } from 'dotenv';
config();

import '@/ai/flows/ai-powered-property-description-generation-flow.ts';