
import type {NextConfig} from 'next';

const nextConfig: NextConfig = {
  /* خيارات الموقع الإلكتروني */
  output: 'export', // يتيح استضافة الموقع كصفحات ثابتة على Firebase Hosting أو أي خادم آخر
  images: {
    unoptimized: true, // يضمن عمل الصور في جميع بيئات الاستضافة الثابتة
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'placehold.co',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'picsum.photos',
        port: '',
        pathname: '/**',
      },
    ],
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
};

export default nextConfig;
